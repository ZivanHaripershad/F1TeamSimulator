The Report Folder contains all the uml diagrams and the final report. 
The System Folder contains all the code for the project. To compile use "make" and to execute use "make run".