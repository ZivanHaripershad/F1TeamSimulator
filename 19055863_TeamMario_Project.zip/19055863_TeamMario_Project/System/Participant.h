#ifndef PARTICIPANT_H
#define PARTICIPANT_H
#include "Ccolleague.h"

class Participant
{
public:
	Ccolleague* colleague;
	int id;
};
#endif