#ifndef TRACKSIMULATION_H
#define TRACKSIMULATION_H
#include "Track.h"

#include <iostream>
#include <string>

using namespace std;

class TrackSimulation
{
	public:

    bool runTrackSimulation(int xp, Track* track);
       
};

#endif