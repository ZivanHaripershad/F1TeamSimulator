#ifndef STRAIGHT_H
#define STRAIGHT_H
#include "TrackD.h"

class Straight: public TrackD
 {
 public:
 	Straight();
 	virtual void printT();
 };
 #endif
