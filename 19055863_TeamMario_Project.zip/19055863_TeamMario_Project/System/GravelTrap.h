#ifndef GRAVELTRAP_H
#define GRAVELTRAP_H
#include "Decorator.h"

class GravelTrap: public Decorator{
public:
	void printT();
};

#endif
