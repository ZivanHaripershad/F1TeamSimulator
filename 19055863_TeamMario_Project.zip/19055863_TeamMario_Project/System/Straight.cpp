#include "Straight.h"

Straight::Straight(){}

void Straight::printT(){
	cout<<"Straight";
} 
