#include "CconcreteMediator.h"

CconcreteMediator::CconcreteMediator(string m){
	message=m;
} 
