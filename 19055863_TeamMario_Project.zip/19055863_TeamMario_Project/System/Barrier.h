#ifndef BARRIER_H
#define BARRIER_H
#include "Decorator.h"

class Barrier: public Decorator{
public:
	void printT();
};

#endif
