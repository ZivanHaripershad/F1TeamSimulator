#ifndef PITSTOP_H
#define PITSTOP_H
#include "Decorator.h"

class Pitstop: public Decorator{
public:
	void printT();
};

#endif