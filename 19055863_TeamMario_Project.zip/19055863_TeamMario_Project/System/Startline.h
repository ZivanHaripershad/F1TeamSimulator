#ifndef STARTLINE_H
#define STARTLINE_H
#include "Decorator.h"

class Startline: public Decorator{
public:
	void printT();
};

#endif 
